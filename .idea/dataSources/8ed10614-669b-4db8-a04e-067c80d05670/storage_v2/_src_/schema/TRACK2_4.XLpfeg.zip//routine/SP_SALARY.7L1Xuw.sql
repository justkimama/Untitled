create procedure sp_salary is v_salary employee.ename%type;
    begin
        select salary into v_salary from EMPLOYEE where ename='SCOTT';
        DBMS_OUTPUT.PUT_LINE(v_salary);
    end;
/

