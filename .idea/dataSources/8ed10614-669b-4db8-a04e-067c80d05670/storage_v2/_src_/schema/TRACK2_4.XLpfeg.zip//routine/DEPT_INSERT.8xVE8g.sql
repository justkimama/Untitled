create procedure dept_insert(
    v_dno in department.dno%type,
    v_dname in department.dname%type,
    v_loc in department.loc%type,
    v_row out number
)
is
begin
insert into DEPARTMENT(dno,dname,loc) values (v_dno,v_dname,v_loc);
select count(*) into v_row from DEPARTMENT;
end;
/

